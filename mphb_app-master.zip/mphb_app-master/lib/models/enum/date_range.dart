class DateRangeEnum {

	static const String TODAY = 'today';
	static const String THIS_WEEK = 'this_week';
	static const String THIS_MONTH = 'this_month';

}
